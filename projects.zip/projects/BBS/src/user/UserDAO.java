package user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
// 데이터베이스 접근객체약자로써 실질적으로 데이터베이스에서
// 회원정보를 불러오거나 데이터베이스에 회원정보를 넣고자할때 쓰입니다.
	private Connection conn; //데이터베이스에 접근하게 해주는 객체
	private PreparedStatement pstmt;
	private ResultSet rs; //어떠한 정보를 담을수 있는 객체
	
	public UserDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS";
			String dbID = "root";
			String dbPassword = "root";
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
